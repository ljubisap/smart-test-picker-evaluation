"""Reuse the committed harness and hash-verified, unchanged pinned selector."""
import hashlib,importlib.util,json,os,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];ITER=ROOT/'iterations/pit-unify';OUT=ITER/'java'
def read(p):return json.loads(p.read_text())
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def list_sha(xs):return hashlib.sha256(b''.join(x.encode()+b'\0' for x in sorted(xs))).hexdigest()
def prepare():
 data=read(ITER/'results/per_record_outcomes.json');by={p['name']:p for p in read(ITER/'projects_unified.json')['projects']};unique={}
 for row in data['records']:
  key=(row['project'],row['mutatedClass'],row['mutatedMethod']);selected=data['selectedSets'][row['base']['selectedSetId']]
  unique.setdefault(key,{'caseId':hashlib.sha256('\0'.join(key).encode()).hexdigest(),'changedClass':key[1],'changedMethod':key[2],'pythonSelected':selected,'occurrences':0})['occurrences']+=1
 maps=[{'project':n,'path':str(ROOT/p['coverageMap']),'mapSha256':sha(ROOT/p['coverageMap']),'cases':[v for k,v in unique.items() if k[0]==n]} for n,p in by.items()]
 write(OUT/'cases.json',{'maps':maps})
def execute():
 build=read(ROOT/'analysis/v14_4_rederivation/java_build.json');artifacts=[build['jar'],*build['runtimeClasspath']]
 verified=[{**a,'actualSha256':sha(Path(a['path']))} for a in artifacts]
 assert all(x['sha256']==x['actualSha256'] for x in verified),'Pinned runtime artifact hash mismatch'
 java=Path('/Library/Java/JavaVirtualMachines/sapmachine-21.jdk/Contents/Home/bin');classes=OUT/'classes';classes.mkdir(parents=True,exist_ok=True)
 cp=os.pathsep.join(a['path'] for a in artifacts);source=ROOT/'analysis/v14_6/harness/SelectorHarness.java'
 commands=[[str(java/'javac'),'-cp',cp,'-d',str(classes),str(source)],[str(java/'java'),'-XX:ActiveProcessorCount=1','-Xmx3g','-cp',str(classes)+os.pathsep+cp,'SelectorHarness',str(OUT/'cases.json'),str(OUT/'output.json')]]
 for index,cmd in enumerate(commands):
  with (OUT/f'command-{index}.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 write(OUT/'runtime.json',{'pinnedBuildSource':'analysis/v14_4_rederivation/java_build.json','commit':build['commit'],'tree':build['tree'],'verifiedArtifacts':verified,'harnessSource':str(source.relative_to(ROOT)),'harnessSha256':sha(source),'commands':commands})
def finalize():
 manifest=read(OUT/'cases.json');raw=read(OUT/'output.json');specs={c['caseId']:c for m in manifest['maps'] for c in m['cases']};rows=[]
 assert set(specs)=={c['caseId'] for c in raw['cases']}
 for j in raw['cases']:
  p=specs[j['caseId']];py=sorted(p['pythonSelected']);js=sorted(j['selectedTests'])
  rows.append({'caseId':j['caseId'],'project':j['project'],'changedClass':p['changedClass'],'changedMethod':p['changedMethod'],'occurrences':p['occurrences'],'javaMode':j['mode'],'javaReason':j.get('reason'),'javaSelectedTests':js,'pythonSelectedTests':py,'javaSha256':list_sha(js),'pythonSha256':list_sha(py),'javaOnly':sorted(set(js)-set(py)),'pythonOnly':sorted(set(py)-set(js)),'match':js==py and j['mode']=='SELECTED'})
 comparison={'uniqueInvocations':len(rows),'weightedOccurrences':sum(r['occurrences'] for r in rows),'mismatches':sum(not r['match'] for r in rows),'nonSelectedModes':sum(r['javaMode']!='SELECTED' for r in rows),'cases':rows,'testSelectorCodeSource':raw['testSelectorCodeSource'],'coverageMapReaderCodeSource':raw['coverageMapReaderCodeSource'],'classBaselineVerification':'OFFLINE_ONLY','constructorVariantVerification':'PYTHON_ONLY'}
 loader={'maps':raw['loader'],'totalDifferentEntries':sum(m['differentEntryCount'] for m in raw['loader']),'totalRawU':sum(len(m['rawU']) for m in raw['loader']),'totalLoadedU':sum(len(m['loadedU']) for m in raw['loader'])}
 write(ITER/'results/java_comparison.json',comparison);write(ITER/'results/loader_content_equality.json',loader)
 print(json.dumps({k:v for k,v in comparison.items() if k not in ('cases',)}));print('Loader differing entries:',loader['totalDifferentEntries'])
 if comparison['mismatches'] or loader['totalDifferentEntries']:raise SystemExit(1)
if __name__=='__main__':prepare();execute();finalize()
