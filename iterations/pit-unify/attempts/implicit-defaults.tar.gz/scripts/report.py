"""Render the iteration report from measured artifacts; no result recomputation."""
import hashlib,json,subprocess
from pathlib import Path
from derive import ROOT,ITER,read,write
def main():
 campaigns=read(ITER/'campaign_inventory.json');summary=read(ITER/'results/summary_tables.json');comparison=read(ITER/'comparison.json');java=read(ITER/'results/java_comparison.json');loader=read(ITER/'results/loader_content_equality.json');taxonomy=read(ITER/'results/residual_taxonomy.json');current=read(ITER/'verification/current/results.json');paper=read(ITER/'manuscript_comparison.json')
 baseline=read(ITER/'baseline_hashes.json');changed=[p for p,h in baseline.items() if not(ROOT/p).exists() or hashlib.sha256((ROOT/p).read_bytes()).hexdigest()!=h]
 preservation={'baselineCommit':read(ITER/'preflight.json')['head'],'trackedFilesChecked':len(baseline),'changedOriginalFiles':changed,'main':subprocess.check_output(['git','rev-parse','main'],cwd=ROOT,text=True).strip(),'branch':subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()}
 write(ITER/'preservation.json',preservation)
 lines=['# PIT 1.17.4 unification iteration','','## Scope and status','',
  'This branch is a separate experiment, not a promotion of current results. Only JGraphT and spring-core PIT matrices were regenerated. Adopted maps, evaluator and policy, sampled classes, targetTests, constructor rule and Hibernate exclusion are unchanged. No coverage was collected; no manuscript or anonymous package was edited.',
  '',f"Baseline: `{preservation['baselineCommit']}`. Branch: `{preservation['branch']}`. Original tracked files checked: {len(baseline)}; changed: {len(changed)}.",'',
  '**Interpretation status: completed unified-operator replay with an explicit environment confound.** The shared-machine CPU control `ActiveProcessorCount=1` is visible to subject code. JGraphT transit-routing tests derive executor parallelism from it. Consequently these results are not certified as a PIT-version-only causal comparison. The historical effective processor count is UNKNOWN here. See `BLOCKERS.md`, `cpu_environment_evidence.json` and `results/status_comparison.json`. Nothing is promoted to current results.',
  '',
  'Both documented runner scripts already requested PIT 1.17.4/JUnit plugin 1.2.1 despite their stored older conditional operators. They were executed unchanged. JGraphT received the documented PIT Maven profile in a disposable POM. Spring used the documented PIT CLI; no Gradle PIT plugin was needed. See `PROTOCOL.md`, `preflight.json`, `pit_tool_artifacts.json` and the retained command logs.',
  '', '## Campaigns','','| Subject | Targeted | Complete matrices | Failed/timed out | Campaign elapsed seconds |','|---|---:|---:|---:|---:|']
 for n,d in campaigns.items():lines.append(f"| {n} | {d['sampledClasses']} | {d['completeClasses']} | {len(d['failedOrTimedOut'])} | {d['campaign']['elapsedSeconds']:.3f} |")
 lines+=['','Per-class mutation/KILLED counts, all PIT statuses, exact scopes, operator distributions, failures and command durations are in `campaign_inventory.json`. Mutant-level TIMEOUT/MEMORY_ERROR statuses remain visible and never enter the KILLED-only denominator. Missing or failed class jobs are not silently replaced by stored matrices.','', '## Unified outcomes','','| Policy | Eligible | Inclusive | Inclusiveness |','|---|---:|---:|---:|']
 for p,m in summary['aggregate'].items():lines.append(f"| {p} | {m['eligible']} | {m['inclusive']} | {m['inclusivenessPctFullPrecision']:.8f}% |")
 lines+=['',f"Residual footprint counts: `{json.dumps(taxonomy['residualFootprintCounts'],sort_keys=True)}`.",f"Residual causal annotations: `{json.dumps(taxonomy['residualCausalMechanismCounts'],sort_keys=True)}`.",
  f"Constructor recoveries: {summary['aggregate']['constructor']['inclusive']-summary['aggregate']['base']['inclusive']}; NO_COVERAGE recoveries: {len(taxonomy['recoveredByNoCoverage'])}.",
  '', 'Unchanged six-subject comparison errors: '+str(len(comparison['unchangedSixSubjectsErrors']))+'. Full selected sets and killers are compared, not only headlines.',
  '', 'The Spring prerequisite correction built only missing runtime project JARs, without a Test task or source change. The initial failed/interrupted attempt is preserved in `pit/spring-core-initial-interrupted/`. The final four unusable jobs are SerializableTypeWrapper, AbstractResource, DataBufferUtils and PathMatchingResourcePatternResolver: each reports 19 unmutated test failures in PIT coverage setup. These same four jobs had no usable stored matrix; DataBufferUtils formerly timed out. This is not an STP failure and no outcome-driven retry was made.',
  '', 'New XML matrices are compressed losslessly for GitHub file limits. `matrix_packaging.json` records raw and gzip hashes and proves identical decompressed bytes. Original raw files are retained outside the repository. Frozen input matrices were not compressed or edited.',
  '', '## Causal review and comparison','',
  'Exact mutation IDs remain those produced by the unchanged loader. New XML paths/ordinals can change IDs even for a corresponding class/method/descriptor/line/operator. `comparison.json` separates exact-ID persistence from semantic correspondence. `causal_source_evidence.json` records source revisions, hashes and line-numbered excerpts; `causal_review.json` records review conclusions. An annotation is not inferred merely from footprint shape. Unsupported causes remain UNDETERMINED. This is source/control-flow analysis, not a new method-entry or probe-offset tracing experiment.',
  '', 'See `COMPARISON.md`, `comparison.json`, `MANUSCRIPT_COMPARISON.md` and `manuscript_comparison.json`. They include per-subject outcomes, Table I–V cells, numerical prose claims, random baselines, Wilson/bootstrap intervals, run-2 sensitivity, failed-killer witnesses and succeedingTests counts. The final DOCX is identified by digest, not copied into this repository.',
  '',f"Manuscript comparison: {len(paper['claims'])} claim/cell entries; {sum(r['changed'] for r in paper['claims'])} changed; unmatched extraction patterns: {len(paper['unmatchedClaimPatterns'])}. Historical execution observations and literature/configuration facts are kept separate from newly derived mutant outcomes.",
  '', '## Java and deterministic verification','',
  f"Production selector: {java['uniqueInvocations']} unique invocations, {java['weightedOccurrences']} weighted occurrences, {java['mismatches']} full-set mismatches, {java['nonSelectedModes']} non-SELECTED modes. Loader differing entries: {loader['totalDifferentEntries']}; raw/loaded U: {loader['totalRawU']}/{loader['totalLoadedU']}.",
  'The existing harness and hash-verified pinned selector are reused. Runtime JAR/dependency hashes and commands are in `java/runtime.json`. Class/constructor policies remain offline research comparisons.',
  '', '| Existing check | Exit | Last line |','|---|---:|---|']
 for r in current['commands']:lines.append(f"| {r['name']} | {r['exitCode']} | {r['lastNonEmptyLine'].replace('|','/')} |")
 verify=ITER/'verification/unified.log'
 if verify.exists():lines+=['','Unified verification: `'+[l for l in verify.read_text().splitlines() if l.strip()][-1]+'`.']
 lines+=['','## Boundaries','',
  'Fixed configuration does not make repeated PIT executions deterministic. Differences can include changed operator semantics and execution-dependent statuses/killing sets; not every numerical difference is attributed uniquely to a specific operator substitution.',
  'Current-results verification logs are separate from the unified verification. Historical model agreement is not reused as production Java proof for new records.',
  '', '## Repository publication','',
  'Commit identity is recorded in the final publication note below. Only `iterations/pit-unify/` is added. `main` and all tags remain untouched. Publication command: `git push origin iteration-pit-unify`.']
 (ITER/'REPORT.md').write_text('\n'.join(lines)+'\n')
 if changed:raise SystemExit('Original files changed: '+str(changed))
if __name__=='__main__':main()
